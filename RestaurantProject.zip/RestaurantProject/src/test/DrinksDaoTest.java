package test;

import Dao.DrinksMenuDao;
import TableModel.Drinks;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class DrinksDaoTest {

    @Test
    public void getEmptyMenuTest() throws IOException, ClassNotFoundException {
        DrinksMenuDao dao=new DrinksMenuDao();
        Map<Integer, Drinks> myMenu =new HashMap<Integer,Drinks>();
        Map<Integer, Drinks> menu= dao.getDrinksMenu();
        Assertions.assertEquals(myMenu.values().toString(),menu.values().toString());

    }


    @Test
    public void update_GetFullMenuTest() throws IOException, ClassNotFoundException {
        DrinksMenuDao dao = new DrinksMenuDao();
        Drinks o1 = new Drinks(11, "burger");
        Drinks o2 = new Drinks(22, "pita");
        Drinks o3 = new Drinks(33, "pizza");
        Map<Integer, Drinks> myMenu =new HashMap<Integer,Drinks>();
        myMenu.put(1,o1);
        myMenu.put(2,o2);
        myMenu.put(3,o3);

        dao.updateFullDrinksMenu(myMenu);
        Map<Integer, Drinks> menu= dao.getDrinksMenu();

        Assertions.assertEquals(myMenu.get(1).getPrice(),menu.get(1).getPrice());
        Assertions.assertEquals(myMenu.get(1).getOrderName(),menu.get(1).getOrderName());
        Assertions.assertEquals(myMenu.get(2).getPrice(),menu.get(2).getPrice());
        Assertions.assertEquals(myMenu.get(2).getOrderName(),menu.get(2).getOrderName());
        Assertions.assertEquals(myMenu.get(3).getPrice(),menu.get(3).getPrice());
        Assertions.assertEquals(myMenu.get(3).getOrderName(),menu.get(3).getOrderName());
    }

    @Test
    public void  addDrinkToMenu() throws IOException, ClassNotFoundException {
        DrinksMenuDao dao = new DrinksMenuDao();
        Drinks o1 = new Drinks(11, "burger");
        Drinks o2 = new Drinks(22, "pita");
        Drinks o3 = new Drinks(33, "pizza");
        Map<Integer, Drinks> myMenu =new HashMap<Integer,Drinks>();
        myMenu.put(1,o1);
        myMenu.put(2,o2);
        myMenu.put(3,o3);

        dao.addDrinkToMenu(1,o1);
        dao.addDrinkToMenu(2,o2);
        dao.addDrinkToMenu(3,o3);

        Map<Integer, Drinks> menu= dao.getDrinksMenu();
        Assertions.assertEquals(myMenu.get(1).getPrice(),menu.get(1).getPrice());
        Assertions.assertEquals(myMenu.get(1).getOrderName(),menu.get(1).getOrderName());
        Assertions.assertEquals(myMenu.get(2).getPrice(),menu.get(2).getPrice());
        Assertions.assertEquals(myMenu.get(2).getOrderName(),menu.get(2).getOrderName());
        Assertions.assertEquals(myMenu.get(3).getPrice(),menu.get(3).getPrice());
        Assertions.assertEquals(myMenu.get(3).getOrderName(),menu.get(3).getOrderName());
    }
}
