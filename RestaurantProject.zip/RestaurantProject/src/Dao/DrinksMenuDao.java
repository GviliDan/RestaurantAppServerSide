package Dao;

import TableModel.Drinks;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class DrinksMenuDao {
    public String path = "menu.txt";
    ObjectOutputStream objectOutputStream;
    ObjectInputStream objectInputStream;

    public DrinksMenuDao() throws IOException {
        objectInputStream =new ObjectInputStream(new FileInputStream(path));
        objectOutputStream =new ObjectOutputStream(new FileOutputStream(path));
        Map<Integer, Drinks> list=new HashMap<Integer,Drinks>();
        objectOutputStream.writeObject(list);
        objectInputStream.close();
        objectOutputStream.close();

    }

    public Map<Integer,Drinks> getDrinksMenu() throws IOException, ClassNotFoundException {
        objectInputStream =new ObjectInputStream(new FileInputStream(path));
        Map<Integer,Drinks> menu=null;
        try{
            menu= (Map<Integer, Drinks>) objectInputStream.readObject();
        }catch (ClassNotFoundException e){
            e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
        }
        objectInputStream.close();
        return menu;
    }


    public void updateFullDrinksMenu(Map<Integer,Drinks> menu) throws IOException {
        objectOutputStream =new ObjectOutputStream(new FileOutputStream(path));
        try {
            objectOutputStream.writeObject(menu);

        }  catch (IOException e){
            e.printStackTrace();
        }
        objectInputStream.close();
    }

    public void addDrinkToMenu(Integer key,Drinks food) throws IOException, ClassNotFoundException {
        Map<Integer, Drinks> list = null;
        list = getDrinksMenu();
        list.put(key,food);
        updateFullDrinksMenu(list);
    }

    public void deleteDrinkFromMenuById(Integer key) throws IOException, ClassNotFoundException{
        Map<Integer, Drinks> list = getDrinksMenu();
        list.remove(key);
        updateFullDrinksMenu(list);
    }
}
