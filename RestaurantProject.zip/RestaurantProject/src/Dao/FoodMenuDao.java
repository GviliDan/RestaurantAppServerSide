package Dao;

import TableModel.Food;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class FoodMenuDao {

    public String path = "menu.txt";
    ObjectOutputStream objectOutputStream;
    ObjectInputStream objectInputStream;

    public FoodMenuDao() throws IOException {
        objectInputStream =new ObjectInputStream(new FileInputStream(path));
        objectOutputStream =new ObjectOutputStream(new FileOutputStream(path));
        Map<Integer, Food> list=new HashMap<Integer,Food>();
        objectOutputStream.writeObject(list);
        objectInputStream.close();
        objectOutputStream.close();

    }

    public Map<Integer,Food> getFoodMenu() throws IOException, ClassNotFoundException {
        objectInputStream =new ObjectInputStream(new FileInputStream(path));
        Map<Integer,Food> menu=null;
        try{
            menu= (Map<Integer, Food>) objectInputStream.readObject();
        }catch (ClassNotFoundException e){
            e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
        }
        objectInputStream.close();
        return menu;
    }

    public void updateFullFoodMenu(Map<Integer,Food> menu) throws IOException {
        objectOutputStream =new ObjectOutputStream(new FileOutputStream(path));
        try {
            objectOutputStream.writeObject(menu);

        }  catch (IOException e){
            e.printStackTrace();
        }
        objectInputStream.close();
    }

    public void addFoodToMenu(Integer key,Food food) throws IOException, ClassNotFoundException {
        Map<Integer, Food> list = null;
        list = getFoodMenu();
        list.put(key,food);
        updateFullFoodMenu(list);
    }

    public void deleteFoodFromMenuById(Integer key) throws IOException, ClassNotFoundException{
        Map<Integer, Food> list = getFoodMenu();
        list.remove(key);
        updateFullFoodMenu(list);
    }
}
