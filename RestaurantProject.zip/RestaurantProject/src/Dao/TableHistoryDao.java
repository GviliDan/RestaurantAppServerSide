package Dao;

import TableModel.Food;
import TableModel.Table;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TableHistoryDao {

    public String path = "TableHistory.txt";

    ObjectOutputStream objectOutputStream;
    ObjectInputStream objectInputStream;


    public TableHistoryDao() throws IOException{
        objectOutputStream =new ObjectOutputStream(new FileOutputStream(path));
        objectInputStream =new ObjectInputStream(new FileInputStream(path));
        ArrayList<Table> list=new ArrayList<Table>();
        objectOutputStream.writeObject(list);
        objectInputStream.close();
        objectOutputStream.close();
    }

    public ArrayList<Table> getFullTableHistory() throws IOException{
        objectInputStream =new ObjectInputStream(new FileInputStream(path));
        ArrayList<Table> tableList= null;
        try{
            tableList= (ArrayList<Table>) objectInputStream.readObject();
        }catch (ClassNotFoundException e){
            e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
        }
        objectInputStream.close();
        return tableList;
    }

    public void updateFullTableHistory(ArrayList<Table> tableArrayList) throws IOException, ClassNotFoundException {
        objectOutputStream =new ObjectOutputStream(new FileOutputStream(path));
        try {
            objectOutputStream.writeObject(tableArrayList);

        }  catch (IOException e){
            e.printStackTrace();
        }
        objectInputStream.close();
    }

    public void archiveTable(Table table) throws IOException , ClassNotFoundException{
        ArrayList<Table> tableArrayList=null;
        tableArrayList= getFullTableHistory();
        tableArrayList.add(table);
        updateFullTableHistory(tableArrayList);
    }


}
