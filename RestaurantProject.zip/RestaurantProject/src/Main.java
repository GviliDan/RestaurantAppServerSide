import TableModel.*;

import java.io.*;
import java.util.Map;
public class Main  {
    public Main() throws IOException {
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException {

//        ArrayList<Order> orderList= new ArrayList<>();
//        Food f1= new Food( 100, "hamburger");
//        Drinks d1=new Drinks( 30, "vodka");
//
//        orderList.add(f1);
//        orderList.add(d1);
//        for (Order order: orderList) {
//            System.out.println(order.getOrderName() +" "+ order.getPrice());
//        }

//                ArrayList<Food> foodArrayList=new ArrayList<>();
//        Integer totalAmount=0;
//        Food f1= new Food( 100, "hamburger");
//        Food f2= new Food( 80, "pasta");
//
//        foodArrayList.add(f1);
//        foodArrayList.add(f2);
//
//        for (Food food: foodArrayList) {
//            totalAmount+= food.getPrice();
//        }
//
//        System.out.println(totalAmount);
//
//        Table table=new Table(4);
//        table.inviteFood(f1);
//        table.inviteFood(f2);

//        for (Food food: table.getFood_order()) {
//            System.out.println(food.getOrderName() + " "+ food.getPrice());
//        }

//        System.out.println(table.getTotalAmount());
//
//        Payment payment= table.getPayment();
//        System.out.println(payment.getTotal_amount());
//        Payment payment= table.getPayment();
//        payment.payBill(100);
//        payment.payBill(20);
//
//        table.printBill();




//        List<Food> list = new ArrayList<>();
//        MenuFileDao dao = new MenuFileDao();
//
//        Food o1 = new Food(11, "burger");
//        Food o2 = new Food(22, "pita");
//        Food o3 = new Food(33, "pizza");


//
//        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("menu.txt"));
//        out.writeObject(menu);
//        out.close();



//        dao.addFood(1,o1);
//        dao.addFood(2,o2);
//        dao.addFood(3,o3);


// ----------------------------------------------------------------------------------------------


//        check for add function
//        Food o4 = new Food(20,"Baget");
//        dao.add(4,o4);
//        System.out.println(dao.get(4));


//----------------------------------------------------------------------------------------------


//        check for get function
//        System.out.println(dao.get(1));;


//----------------------------------------------------------------------------------------------


//        check for getALL function
//        list = dao.getAll();
//        System.out.println(list.get(0));
//        System.out.println(list.get(1));
//        System.out.println(list.get(2));



//----------------------------------------------------------------------------------------------


//        check search function
//        System.out.println(dao.search("pizza"));


//----------------------------------------------------------------------------------------------


//        check for delete function
//        dao.delete(2);
//
//        ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream("menu.txt"));
//        Map<Integer, Food> menu = (Map<Integer, Food>) objectInputStream.readObject();
//        System.out.println(menu);
//        System.out.println(menu.get(1));
//        System.out.println(menu.get(2));
//        System.out.println(menu.get(3));



//        System.out.println(list.get(0));
//        System.out.println(list.get(1));
//        System.out.println(list.get(2));
//        ObjectInputStream in = new ObjectInputStream(new FileInputStream("menu.txt"));
//        Map<Integer, Food> dan = new HashMap<>();
//        dan = (Map<Integer,Food>) in.readObject();
//        dan.remove(1);
//        System.out.println(dan.get(1));
//        System.out.println(dan.get(2));
//        in.close();
//

    }
}