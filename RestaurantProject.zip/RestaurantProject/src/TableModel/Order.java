package TableModel;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public abstract class Order implements Serializable {
    Integer price;
    String orderName;

    public Order(Integer price,String orderName) {
        this.price = price;
        this.orderName = orderName;
    }


    public Order() {

    }

    public String getOrderName() {
        return orderName;
    }

    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

}
