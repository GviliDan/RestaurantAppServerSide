package TableModel;

public class Drinks extends Order {

    private String barComments;


    public Drinks(Integer price, String orderName) {
        super();
        this.price= price;
        this.orderName= orderName;
        this.barComments="";
    }

    public String getBarComments() {
        return barComments;
    }

    public void setBarComments(String barComments) {
        this.barComments = barComments;
    }




}
