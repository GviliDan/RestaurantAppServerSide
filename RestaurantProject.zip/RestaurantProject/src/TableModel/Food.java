package TableModel;

import java.io.Serializable;

public class Food extends Order implements Serializable {

    private String kitchunComments;
    public Food(Integer price, String orderName) {
        super();
        this.price= price;
        this.orderName= orderName;
    }

    public Food() {

    }

    public String toString(){
        return "price= "+price+" name= "+orderName+" " ;
    }

    public void setKitchunComments(String kitchunComments) {
        this.kitchunComments = kitchunComments;
    }

    public String getKitchunComments() {
        return kitchunComments;
    }
}
